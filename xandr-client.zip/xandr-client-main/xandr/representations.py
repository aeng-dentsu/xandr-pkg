def raw(client, service, obj):
    return obj


__all__ = ["raw"]
