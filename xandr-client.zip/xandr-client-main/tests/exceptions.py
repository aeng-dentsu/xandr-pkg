import pytest

from xandr.exceptions import XandrException, BadCredentials


@pytest.fixture
def xandr_exception(mocker):
    response = mocker.MagicMock()
    response.json.return_value = {
        "response": {
            "error_code": "INVALID_LOGIN",
            "error_id": "INVALID_LOGIN",
            "error": "You didn't provided credentials"
        }
    }
    return XandrException(response)


@pytest.fixture
def empty_xandr_exception():
    return XandrException()


@pytest.fixture
def bad_credentials():
    return BadCredentials()


def test_xandr_exception_str(xandr_exception):
    assert "INVALID_LOGIN" in str(xandr_exception)


def test_empty_xandr_exception_str(empty_xandr_exception):
    assert "Error" in str(empty_xandr_exception)


def test_bad_credentials_str(bad_credentials):
    assert "bad credentials" in str(bad_credentials)
