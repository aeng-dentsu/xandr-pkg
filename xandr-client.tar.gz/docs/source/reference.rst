API reference
#############

Client
======

.. automodule:: xandr.client
    :members:
    :undoc-members:

Cursor
======

.. automodule:: xandr.cursor
    :members:
    :undoc-members:

Exceptions
==========

.. automodule:: xandr.exceptions
    :members:
    :undoc-members:

Model
=====

.. automodule:: xandr.model
    :members: Model
    :undoc-members:

Services
--------

.. automodule:: xandr.model
    :members:
    :undoc-members:
    :exclude-members: Model

Representations
===============

.. automodule:: xandr.representations
    :members:
    :undoc-members:

Utils
=====

.. automodule:: xandr.utils
    :members:
    :undoc-members:
