import os
import subprocess
import sys

from setuptools import setup


def get_version():
    if not os.path.isdir(".git"):
        sys.stderr.write("This does not appear to be a Git repository.")
        return ""
    return subprocess.check_output(["git", "describe", "--tags", "--always"],
                                   universal_newlines=True)[:-1]


def get_description():
    with open("README.rst") as file:
        return file.read()


setup(
    name="Xandr-client",
    version=get_version(),
    license="MIT",
    author="numberly",
    author_email="angela.eng@dentsu.com",
    description="General purpose Python client for the Xandr API",
    long_description=get_description(),
    url="https://github.com/aeng-dentsu/xandr-client",
    download_url="https://github.com/naeng-dentsu/xandr-clien/tags",
    platforms="any",
    packages=["xandr"],
    install_requires=["requests>=2.20.0",
                      "Thingy>=0.8.3"],
    classifiers=[
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Topic :: Software Development :: Libraries :: Python Modules"
    ]
)
