class XandrException(Exception):
    """Represents a generic Xandr Exception"""

    def __init__(self, response=None):
        self.response = response

    def __str__(self):
        if not self.response:
            return "Error with Xandr API"
        data = self.response.json()["response"]
        error_name = data.get("error_code", data["error_id"])
        description_error = data.get("error", "(indisponible)")
        return "{}: {}".format(error_name, description_error)


class RateExceeded(XandrException):
    """Exception raised when the client reached the rate limit"""
    pass


class NoAuth(XandrException):
    """Exception raised when the client's authentication expired"""
    pass


class BadCredentials(XandrException):
    """Exception raised when wrong credentials are provided"""

    def __str__(self):
        return "You provided bad credentials for the Xandr API"


__all__ = ["XandrException", "RateExceeded", "NoAuth", "BadCredentials"]
